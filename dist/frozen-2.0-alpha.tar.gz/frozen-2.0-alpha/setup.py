from setuptools import setup

setup(name="frozen",
		version="2.0-alpha",
		author="Malex",
		license="GNU/GPL3",
		description="A simple but cool framework for wsgi",
		packages=['frozen'],
		package_dir={"frozen":"src"},
		)
